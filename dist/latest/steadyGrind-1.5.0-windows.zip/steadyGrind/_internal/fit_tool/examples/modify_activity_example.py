from pathlib import Path

from fit_tool.fit_file import FitFile
from fit_tool.fit_file_builder import FitFileBuilder
from fit_tool.profile.messages.record_message import RecordHeartRateField, RecordMessage, RecordPowerField


def main():
    """The following program reads all the bytes from a FIT formatted file and then
        decodes these bytes to create a FIT file object. We then build a modified FIT file
        based on a variety of criteria (see comments below). Finally we output
        the modified data to a new FIT file.
    """
    root = Path(__file__).resolve().parents[2]
    path = root / 'fit_tool' / 'tests' / 'data' / 'sdk' / 'Activity.fit'
    fit_file = FitFile.from_file(str(path))

    builder = FitFileBuilder(auto_define=False)

    for record in fit_file.records:
        message = record.message
        include_record = True

        if message.global_id == RecordMessage.ID:
            # Remove the heart rate field from all record definition and data messages
            message.remove_field(RecordHeartRateField.ID)

            if isinstance(message, RecordMessage):
                # remove records where the power is too high
                power_field = message.get_field(RecordPowerField.ID)
                if power_field and power_field.is_valid():
                    power = power_field.get_value()
                    if power > 800:
                        include_record = False

        if include_record:
            builder.add(message)

    modified_file = builder.build()
    out_path = root / 'fit_tool' / 'tests' / 'out' / 'modified_activity.fit'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    modified_file.to_file(str(out_path))

    FitFile.from_file(str(out_path))


if __name__ == "__main__":
    main()
